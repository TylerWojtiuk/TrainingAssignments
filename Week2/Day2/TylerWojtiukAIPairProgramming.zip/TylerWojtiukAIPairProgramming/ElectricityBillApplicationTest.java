package com.citypower.billing;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class ElectricityBillApplicationTest {

	@Test
	void testZeroUnits() {
		double energyCharge = ElectricityBillApplication.calculateEnergyCharge(0);

		assertEquals(0.00, energyCharge, 0.001);
		assertEquals(0.00,
				ElectricityBillApplication.calculateSurcharge(energyCharge), 0.001);
		assertEquals(50.00,
				ElectricityBillApplication.calculateTotal(energyCharge), 0.001);
	}

	@Test
	void test80UnitsWithinFirstSlab() {
		double energyCharge = ElectricityBillApplication.calculateEnergyCharge(80);

		assertEquals(240.00, energyCharge, 0.001);
		assertEquals(0.00,
				ElectricityBillApplication.calculateSurcharge(energyCharge), 0.001);
		assertEquals(290.00,
				ElectricityBillApplication.calculateTotal(energyCharge), 0.001);
	}

	@Test
	void test100UnitsAtFirstSlabBoundary() {
		double energyCharge = ElectricityBillApplication.calculateEnergyCharge(100);

		assertEquals(300.00, energyCharge, 0.001);
		assertEquals(0.00,
				ElectricityBillApplication.calculateSurcharge(energyCharge), 0.001);
		assertEquals(350.00,
				ElectricityBillApplication.calculateTotal(energyCharge), 0.001);
	}

	@Test
	void test101UnitsAtSecondSlabBoundary() {
		double energyCharge = ElectricityBillApplication.calculateEnergyCharge(101);

		assertEquals(305.00, energyCharge, 0.001);
		assertEquals(0.00,
				ElectricityBillApplication.calculateSurcharge(energyCharge), 0.001);
		assertEquals(355.00,
				ElectricityBillApplication.calculateTotal(energyCharge), 0.001);
	}

	@Test
	void test300UnitsAtSecondSlabLimit() {
		double energyCharge = ElectricityBillApplication.calculateEnergyCharge(300);

		assertEquals(1300.00, energyCharge, 0.001);
		assertEquals(0.00,
				ElectricityBillApplication.calculateSurcharge(energyCharge), 0.001);
		assertEquals(1350.00,
				ElectricityBillApplication.calculateTotal(energyCharge), 0.001);
	}

	@Test
	void test301UnitsAtThirdSlabEntry() {
		double energyCharge = ElectricityBillApplication.calculateEnergyCharge(301);

		assertEquals(1307.50, energyCharge, 0.001);
		assertEquals(0.00,
				ElectricityBillApplication.calculateSurcharge(energyCharge), 0.001);
		assertEquals(1357.50,
				ElectricityBillApplication.calculateTotal(energyCharge), 0.001);
	}

	@Test
	void test393UnitsAtSurchargeLimit() {
		double energyCharge = ElectricityBillApplication.calculateEnergyCharge(393);

		assertEquals(1997.50, energyCharge, 0.001);
		assertEquals(0.00,
				ElectricityBillApplication.calculateSurcharge(energyCharge), 0.001);
		assertEquals(2047.50,
				ElectricityBillApplication.calculateTotal(energyCharge), 0.001);
	}

	@Test
	void test394UnitsAboveSurchargeLimit() {
		double energyCharge = ElectricityBillApplication.calculateEnergyCharge(394);

		assertEquals(2005.00, energyCharge, 0.001);
		assertEquals(100.25,
				ElectricityBillApplication.calculateSurcharge(energyCharge), 0.001);
		assertEquals(2155.25,
				ElectricityBillApplication.calculateTotal(energyCharge), 0.001);
	}

	@Test
	void test400UnitSampleBill() {
		double energyCharge = ElectricityBillApplication.calculateEnergyCharge(400);

		assertEquals(2050.00, energyCharge, 0.001);
		assertEquals(102.50,
				ElectricityBillApplication.calculateSurcharge(energyCharge), 0.001);
		assertEquals(2202.50,
				ElectricityBillApplication.calculateTotal(energyCharge), 0.001);
	}
}
