package com.citypower.billing;

import java.util.Scanner;

public class ElectricityBillApplication {

	// Progressive energy-charge slab constants
	public static final int FIRST_SLAB_UNITS = 100;
	public static final int SECOND_SLAB_UNITS = 200;
	public static final int THIRD_SLAB_START = FIRST_SLAB_UNITS + SECOND_SLAB_UNITS;

	public static final double FIRST_SLAB_RATE = 3.00;
	public static final double SECOND_SLAB_RATE = 5.00;
	public static final double THIRD_SLAB_RATE = 7.50;

	// Fixed charge and surcharge constants
	public static final double FIXED_CHARGE = 50.00;
	public static final double SURCHARGE_LIMIT = 2000.00;
	public static final double SURCHARGE_RATE = 0.05;

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter consumer number: ");
		String consumerNumber = scanner.nextLine();

		System.out.print("Enter consumer name: ");
		String consumerName = scanner.nextLine();

		System.out.print("Enter previous meter reading: ");
		if (!scanner.hasNextInt()) {
			System.out.println("Error: Meter readings must be whole numbers.");
			scanner.next();
			scanner.close();
			return;
		}
		int previousReading = scanner.nextInt();

		System.out.print("Enter current meter reading: ");
		if (!scanner.hasNextInt()) {
			System.out.println("Error: Meter readings must be whole numbers.");
			scanner.next();
			scanner.close();
			return;
		}
		int currentReading = scanner.nextInt();

		// Reject negative readings and a decreasing meter reading.
		if (previousReading < 0 || currentReading < 0) {
			System.out.println("Error: Meter readings cannot be negative.");
			scanner.close();
			return;
	}

		if (currentReading < previousReading) {
			System.out.println("Error: Current meter reading cannot be less than previous meter reading.");
			scanner.close();
			return;
		}

		int unitsConsumed = currentReading - previousReading;
		double energyCharge = calculateEnergyCharge(unitsConsumed);
		double surcharge = calculateSurcharge(energyCharge);
		double totalAmount = calculateTotal(energyCharge);

		printBill(consumerNumber, consumerName, unitsConsumed,
				energyCharge, surcharge, totalAmount);

		scanner.close();
	}

	public static double calculateEnergyCharge(int units) {
		double energyCharge = 0.0;

		// Calculate the first 100 units at Rs. 3.00 per unit.
		if (units <= FIRST_SLAB_UNITS) {
			energyCharge = units * FIRST_SLAB_RATE;
		} else {
			energyCharge = FIRST_SLAB_UNITS * FIRST_SLAB_RATE;

			// Calculate the next 200 units (101-300) at Rs. 5.00 per unit.
			if (units <= THIRD_SLAB_START) {
				energyCharge = energyCharge
						+ (units - FIRST_SLAB_UNITS) * SECOND_SLAB_RATE;
			} else {
				energyCharge = energyCharge
						+ SECOND_SLAB_UNITS * SECOND_SLAB_RATE;

				// Calculate units above 300 at Rs. 7.50 per unit.
				energyCharge = energyCharge
						+ (units - THIRD_SLAB_START) * THIRD_SLAB_RATE;
			}
		}

		return energyCharge;
	}

	public static double calculateSurcharge(double energyCharge) {
		double surcharge = 0.0;

		// The surcharge applies only when the energy charge is strictly above Rs. 2,000.
		if (energyCharge > SURCHARGE_LIMIT) {
			surcharge = energyCharge * SURCHARGE_RATE;
		}

		return surcharge;
	}

	public static double calculateTotal(double energyCharge) {
		double surcharge = calculateSurcharge(energyCharge);
		double totalAmount = energyCharge + FIXED_CHARGE + surcharge;
		return totalAmount;
	}

	public static void printBill(
			String consumerNumber,
			String consumerName,
			int unitsConsumed,
			double energyCharge,
			double surcharge,
			double totalAmount) {

		System.out.println();
		System.out.println("-------- CityPower Electricity Bill --------");
		System.out.println("Consumer Number : " + consumerNumber);
		System.out.println("Consumer Name   : " + consumerName);
		System.out.println("Units Consumed  : " + unitsConsumed);
		System.out.printf("Energy Charge   : Rs. %.2f%n", energyCharge);
		System.out.printf("Fixed Charge    : Rs. %.2f%n", FIXED_CHARGE);
		System.out.printf("Surcharge       : Rs. %.2f%n", surcharge);
		System.out.printf("Total Amount    : Rs. %.2f%n", totalAmount);
	}
}